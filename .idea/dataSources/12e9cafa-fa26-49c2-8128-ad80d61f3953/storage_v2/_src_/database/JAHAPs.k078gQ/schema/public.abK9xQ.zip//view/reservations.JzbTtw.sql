create view reservations
            (orderer_christianname, orderer_city, orderer_email, orderer_name, orderer_phone, orderer_street,
             orderer_zipcode, orderer_greeting, orderer_salutation, orderer_title, orderer_remarks,
             orderer_language_code, orderer_language_name, guest_christianname, guest_city, guest_email, guest_name,
             guest_phone, guest_street, guest_zipcode, guest_greeting, guest_salutation, guest_title, guest_remarks,
             guest_language_code, guest_language_name, services_fromdate, services_todate, services_price,
             services_amount, name, code, resno, departuredate, cat_name, cat_description, arrivaldate, hotel_name,
             hotel_code, hotel_bankaccountdata1, hotel_bankaccountdata2, hotel_footertext, id)
as
SELECT orderer.christianname          AS orderer_christianname,
       orderer.city                   AS orderer_city,
       orderer.email                  AS orderer_email,
       orderer.name                   AS orderer_name,
       orderer.phone                  AS orderer_phone,
       orderer.street                 AS orderer_street,
       orderer.zipcode                AS orderer_zipcode,
       orderer.greeting               AS orderer_greeting,
       orderer.salutation             AS orderer_salutation,
       orderer.title                  AS orderer_title,
       orderer.remarks                AS orderer_remarks,
       orderer_language.language_code AS orderer_language_code,
       orderer_language.language_name AS orderer_language_name,
       guest.christianname            AS guest_christianname,
       guest.city                     AS guest_city,
       guest.email                    AS guest_email,
       guest.name                     AS guest_name,
       guest.phone                    AS guest_phone,
       guest.street                   AS guest_street,
       guest.zipcode                  AS guest_zipcode,
       guest.greeting                 AS guest_greeting,
       guest.salutation               AS guest_salutation,
       guest.title                    AS guest_title,
       guest.remarks                  AS guest_remarks,
       guest_language.language_code   AS guest_language_code,
       guest_language.language_name   AS guest_language_name,
       services.fromdate              AS services_fromdate,
       services.todate                AS services_todate,
       services.price                 AS services_price,
       services.amount                AS services_amount,
       rooms.name,
       rooms.code,
       res.resno,
       res.departuredate,
       cat.cat_name,
       cat.cat_description,
       res.arrivaldate,
       hotel.hotel_name,
       hotel.hotel_code,
       hotel.hotel_bankaccountdata1,
       hotel.hotel_bankaccountdata2,
       hotel.hotel_footertext,
       occ.id
FROM accounts
         LEFT JOIN csc services ON accounts.cscservice = services.id,
     occ
         LEFT JOIN address guest ON occ.guest = guest.id
         LEFT JOIN language guest_language ON guest.language = guest_language.id,
     res
         LEFT JOIN address orderer ON res.addressid = orderer.id
         LEFT JOIN language orderer_language ON orderer.language = orderer_language.id,
     rooms
         LEFT JOIN cat ON rooms.cat = cat.id,
     hotel
WHERE occ.room = rooms.id
  AND res.id = occ.res
  AND occ.account = accounts.id;

alter table reservations
    owner to postgres;

