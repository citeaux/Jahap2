create view "LocationAddress"
            (floor, id, building, christianname, city, email, name, phone, street, zipcode, country, currency, language,
             homepage, remarks, greeting, salutation, title, addresstype)
as
SELECT location.floor,
       location.id,
       location.building,
       address.christianname,
       address.city,
       address.email,
       address.name,
       address.phone,
       address.street,
       address.zipcode,
       address.country,
       address.currency,
       address.language,
       address.homepage,
       address.remarks,
       address.greeting,
       address.salutation,
       address.title,
       address.addresstype
FROM location
         LEFT JOIN address ON location.address_id = address.id;

alter table "LocationAddress"
    owner to postgres;

