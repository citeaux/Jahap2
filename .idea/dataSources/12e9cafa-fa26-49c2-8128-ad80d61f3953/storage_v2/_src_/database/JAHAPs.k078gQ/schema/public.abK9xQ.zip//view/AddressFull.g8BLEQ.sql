create view "AddressFull"
            (country_code, country_name, currency_code, currency_name, currency_symbol, language_code, language_name,
             id, christianname, city, email, name, phone, zipcode, street, homepage, remarks, greeting, salutation,
             title, addresstype)
as
SELECT country.country_code,
       country.country_name,
       currency.currency_code,
       currency.currency_name,
       currency.currency_symbol,
       language.language_code,
       language.language_name,
       address.id,
       address.christianname,
       address.city,
       address.email,
       address.name,
       address.phone,
       address.zipcode,
       address.street,
       address.homepage,
       address.remarks,
       address.greeting,
       address.salutation,
       address.title,
       address.addresstype
FROM address
         LEFT JOIN language ON address.language = language.id
         LEFT JOIN currency ON address.currency = currency.id
         LEFT JOIN country ON address.country = country.id;

alter table "AddressFull"
    owner to postgres;

