create view "TotalAmountOfCatRooms"(amount, cat_name, cat_description, id) as
SELECT count(*) AS amount,
       cat.cat_name,
       cat.cat_description,
       cat.id
FROM rooms,
     cat
WHERE rooms.cat = cat.id
GROUP BY cat.id;

alter table "TotalAmountOfCatRooms"
    owner to postgres;

