create view "ArrDepAll"(alldepartures, allarrivals, allrooms, occrooms) as
SELECT (SELECT count(occcat.departuredate) AS count
        FROM rooms,
             occcat
        WHERE rooms.cat = occcat.cat
          AND occcat.departuredate = now()) AS alldepartures,
       (SELECT count(occcat.departuredate) AS count
        FROM rooms,
             occcat
        WHERE rooms.cat = occcat.cat
          AND occcat.arrivaldate = now())   AS allarrivals,
       (SELECT count(rooms.*) AS count
        FROM rooms)                         AS allrooms,
       (SELECT count(DISTINCT occcat.id) AS count
        FROM rooms,
             occcat
        WHERE rooms.cat = occcat.cat
          AND occcat.departuredate > now()
          AND occcat.arrivaldate < now())   AS occrooms;

alter table "ArrDepAll"
    owner to postgres;

