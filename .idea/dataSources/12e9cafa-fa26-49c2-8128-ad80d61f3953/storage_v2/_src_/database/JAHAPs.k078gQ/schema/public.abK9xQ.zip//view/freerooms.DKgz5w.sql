create view freerooms(freerooms) as
SELECT "ArrDepAll".allrooms - "ArrDepAll".allarrivals - "ArrDepAll".occrooms AS freerooms
FROM "ArrDepAll";

alter table freerooms
    owner to postgres;

