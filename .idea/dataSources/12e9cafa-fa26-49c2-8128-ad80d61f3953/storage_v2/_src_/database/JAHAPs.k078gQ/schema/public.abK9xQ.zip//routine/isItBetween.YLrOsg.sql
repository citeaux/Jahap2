create function "isItBetween"(date, date, date) returns boolean
    language plpgsql
as
$$
BEGIN
   IF $1 <= $3 THEN
       IF $3 <= $2 THEN
          RETURN TRUE;
       ELSE
          RETURN FALSE;
        END IF;
    END IF;       
END;
$$;

alter function "isItBetween"(date, date, date) owner to postgres;

