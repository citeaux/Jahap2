create view dayclose(type, name, position, id_jobscheduler, id_job, id, definition) as
SELECT jobs.type,
       jobs.name,
       job_jobscheduler."position",
       job_jobscheduler.id_jobscheduler,
       job_jobscheduler.id_job,
       job_jobscheduler.id,
       jobs.definition
FROM job_jobscheduler,
     jobs,
     jobscheduler
WHERE job_jobscheduler.id_job = jobs.id
  AND job_jobscheduler.id_jobscheduler = jobscheduler.id
  AND jobscheduler.typ = 'dayclose'::bpchar
ORDER BY job_jobscheduler."position";

alter table dayclose
    owner to postgres;

