create function foox() returns void
    language sql
as
$$
    CREATE FUNCTION foox() RETURNS void AS
$BODY$
  DECLARE
      zahl_antwort INTEGER;
      zahl_lösung INTEGER := 42;
  BEGIN
    zahl_antwort := zahl_lösung;
    RAISE NOTICE  'Die Antwort lautet %.', zahl_antwort;-- % wird durch die Variable ersetzt
    -- return true;
  END;
$BODY$ LANGUAGE plpgsql;
    $$;

alter function foox() owner to postgres;

