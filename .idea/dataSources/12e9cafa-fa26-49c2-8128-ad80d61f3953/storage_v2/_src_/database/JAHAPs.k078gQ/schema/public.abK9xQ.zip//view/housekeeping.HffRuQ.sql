create view housekeeping(id, code, cat_name, floor, clean, blocks) as
SELECT rooms.id,
       rooms.code,
       cat.cat_name,
       location.floor,
       rooms.clean,
       string_agg(concat(to_char(occ.arrivaldate::timestamp with time zone, 'DD.MM.YYYY'::text), '-',
                         to_char(occ.departuredate::timestamp with time zone, 'DD.MM.YYYY'::text)),
                  ' / '::text) AS blocks
FROM location,
     cat,
     rooms
         LEFT JOIN occ ON rooms.id = occ.room AND occ.arrivaldate >= 'now'::text::date AND occ.housekeeping IS NOT NULL
WHERE rooms.location = location.id
  AND rooms.cat = cat.id
GROUP BY rooms.code, rooms.id, location.floor, cat.cat_name;

comment on view housekeeping is 'Shows all Rooms with Housekeepingblocks form current date to the futur';

alter table housekeeping
    owner to postgres;

