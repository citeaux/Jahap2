--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

DROP DATABASE "JAHAPs";
--
-- Name: JAHAPs; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "JAHAPs" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE "JAHAPs" OWNER TO postgres;

\connect "JAHAPs"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: foox(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION foox() RETURNS void
    LANGUAGE sql
    AS $_$CREATE FUNCTION foox() RETURNS void AS
$BODY$
  DECLARE
      zahl_antwort INTEGER;
      zahl_lösung INTEGER := 42;
  BEGIN
    zahl_antwort := zahl_lösung;
    RAISE NOTICE  'Die Antwort lautet %.', zahl_antwort;-- % wird durch die Variable ersetzt
    -- return true;
  END;
$BODY$ LANGUAGE plpgsql;$_$;


ALTER FUNCTION public.foox() OWNER TO postgres;

--
-- Name: isItBetween(date, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "isItBetween"(date, date, date) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
   IF $1 <= $3 THEN
       IF $3 <= $2 THEN
          RETURN TRUE;
       ELSE
          RETURN FALSE;
        END IF;
    END IF;       
END;
$_$;


ALTER FUNCTION public."isItBetween"(date, date, date) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE address (
    id bigint NOT NULL,
    christianname character varying(255),
    city character varying(255),
    email character varying(255),
    name character varying(255),
    phone character varying(255),
    street character varying(255),
    zipcode character varying(255),
    country integer,
    currency integer,
    language integer,
    homepage character varying(100),
    remarks character varying(200),
    greeting character varying(50),
    salutation character varying(50),
    title character varying(50),
    addresstype character varying(100)
);


ALTER TABLE public.address OWNER TO root;

--
-- Name: country; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE country (
    id integer NOT NULL,
    country_code character varying(10),
    country_name character varying(100),
    language integer,
    currency integer
);


ALTER TABLE public.country OWNER TO root;

--
-- Name: currency; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE currency (
    id integer NOT NULL,
    currency_code character varying(255),
    currency_name character varying(255),
    currency_symbol character(1)
);


ALTER TABLE public.currency OWNER TO root;

--
-- Name: language; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE language (
    id integer NOT NULL,
    language_code character varying(5),
    language_name character varying(50)
);


ALTER TABLE public.language OWNER TO root;

--
-- Name: AddressFull; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "AddressFull" AS
 SELECT country.country_code,
    country.country_name,
    currency.currency_code,
    currency.currency_name,
    currency.currency_symbol,
    language.language_code,
    language.language_name,
    address.id,
    address.christianname,
    address.city,
    address.email,
    address.name,
    address.phone,
    address.zipcode,
    address.street,
    address.homepage,
    address.remarks,
    address.greeting,
    address.salutation,
    address.title,
    address.addresstype
   FROM (((address
     LEFT JOIN language ON ((address.language = language.id)))
     LEFT JOIN currency ON ((address.currency = currency.id)))
     LEFT JOIN country ON ((address.country = country.id)));


ALTER TABLE public."AddressFull" OWNER TO postgres;

--
-- Name: location; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE location (
    id smallint NOT NULL,
    building character varying(100),
    floor character varying(100),
    address_id integer
);


ALTER TABLE public.location OWNER TO root;

--
-- Name: LocationAddress; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "LocationAddress" AS
 SELECT location.floor,
    location.id,
    location.building,
    address.christianname,
    address.city,
    address.email,
    address.name,
    address.phone,
    address.street,
    address.zipcode,
    address.country,
    address.currency,
    address.language,
    address.homepage,
    address.remarks,
    address.greeting,
    address.salutation,
    address.title,
    address.addresstype
   FROM (location
     LEFT JOIN address ON ((location.address_id = address.id)));


ALTER TABLE public."LocationAddress" OWNER TO postgres;

--
-- Name: TotalAmountOfCatRooms; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "TotalAmountOfCatRooms" (
    amount bigint,
    cat_name character varying(100),
    cat_description character varying(255),
    id integer
);


ALTER TABLE public."TotalAmountOfCatRooms" OWNER TO postgres;

--
-- Name: account_position; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE account_position (
    id bigint NOT NULL,
    bill bigint,
    vat bigint,
    payment bigint,
    billed boolean,
    amount integer,
    price numeric(8,2),
    debit boolean,
    rate bigint,
    canceledposition bigint,
    canceled boolean,
    ratedate date,
    account bigint,
    positionname character varying(255)
);


ALTER TABLE public.account_position OWNER TO root;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE accounts (
    id bigint NOT NULL,
    balance numeric(5,0),
    checkout boolean,
    cscservice bigint,
    address bigint,
    reservation bigint,
    checkindate date,
    checkoutdate date
);


ALTER TABLE public.accounts OWNER TO root;

--
-- Name: bill; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bill (
    id bigint NOT NULL,
    billno bigint,
    address bigint,
    billdate date,
    billname character varying(100),
    canceled boolean,
    canceledbill bigint,
    total numeric(8,2),
    billnostring character varying(200),
    uuid character varying(200),
    billchange timestamp without time zone,
    temp_bill boolean
);


ALTER TABLE public.bill OWNER TO root;

--
-- Name: bill_no; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bill_no (
    billno bigint NOT NULL
);


ALTER TABLE public.bill_no OWNER TO root;

--
-- Name: cat; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cat (
    id integer NOT NULL,
    cat_name character varying(100),
    cat_description character varying(255)
);


ALTER TABLE public.cat OWNER TO root;

--
-- Name: occ; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE occ (
    id bigint NOT NULL,
    arrivaltime time without time zone,
    departuretime time without time zone,
    arrivaldate date,
    guest bigint NOT NULL,
    departuredate date,
    room bigint,
    res bigint,
    account bigint,
    maintenance bigint,
    housekeeping bigint,
    pax smallint
);


ALTER TABLE public.occ OWNER TO root;

--
-- Name: res; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE res (
    id bigint NOT NULL,
    resno character varying(50),
    addressid bigint,
    arrivaltime time without time zone,
    arrivaldate date,
    departuredate date,
    departuretime timestamp without time zone,
    state integer,
    comment text,
    optiondate date
);


ALTER TABLE public.res OWNER TO root;

--
-- Name: rooms; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE rooms (
    id bigint NOT NULL,
    category character varying(255),
    code character varying(255),
    name character varying(255),
    cat integer,
    location integer,
    clean boolean,
    no_maintenance boolean,
    pax smallint
);


ALTER TABLE public.rooms OWNER TO root;

--
-- Name: checkin; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW checkin AS
 SELECT res.resno,
    occ.id,
    occ.arrivaltime,
    occ.departuretime,
    occ.arrivaldate,
    occ.departuredate,
    occ.maintenance,
    occ.housekeeping,
    cat.cat_name,
    cat.cat_description,
    rooms.code,
    rooms.name,
    rooms.clean,
    rooms.no_maintenance,
    "LocationAddress".floor AS location_floor,
    "LocationAddress".building AS location_building,
    "LocationAddress".christianname AS location_christianname,
    "LocationAddress".city AS location_address_city,
    "LocationAddress".email AS location_address_email,
    "LocationAddress".name AS location_address_name,
    "LocationAddress".phone AS location_address_phone,
    "LocationAddress".street AS location_address_street,
    "LocationAddress".zipcode AS location_address_zipcode,
    "LocationAddress".country AS location_address_country,
    "LocationAddress".currency AS location_address_currency,
    "LocationAddress".language AS location_address_language,
    "LocationAddress".homepage AS location_address_homepage,
    "LocationAddress".remarks AS location_address_remarks,
    "LocationAddress".greeting AS location_address_greeting,
    "LocationAddress".salutation AS location_address_salutation,
    "LocationAddress".title AS location_address_title,
    "LocationAddress".addresstype AS location_address_addresstype,
    reservation_adress.country_code AS reservation_address_country_code,
    reservation_adress.country_name AS reservation_address_country_name,
    reservation_adress.currency_code AS reservation_address_currency_code,
    reservation_adress.currency_name AS reservation_address_currency_name,
    reservation_adress.currency_symbol AS reservation_address_currency_symbol,
    reservation_adress.language_code AS reservation_address_language_code,
    reservation_adress.language_name AS reservation_address_language_name,
    reservation_adress.christianname AS reservation_address_christianname,
    reservation_adress.city AS reservation_address_city,
    reservation_adress.email AS reservation_address_email,
    reservation_adress.name AS reservation_address_name,
    reservation_adress.phone AS reservation_address_phone,
    reservation_adress.zipcode AS reservation_address_zipcode,
    reservation_adress.street AS reservation_address_street,
    reservation_adress.homepage AS reservation_address_homepage,
    reservation_adress.remarks AS reservation_address_remarks,
    reservation_adress.greeting AS reservation_address_greeting,
    reservation_adress.salutation AS reservation_address_salutation,
    reservation_adress.title AS reservation_address_title,
    reservation_adress.addresstype AS reservation_address_addresstype,
    guest_adress.country_code AS guest_adress_country_code,
    guest_adress.country_name AS guest_adress_country_name,
    guest_adress.currency_code AS guest_adress_currency_code,
    guest_adress.currency_name AS guest_adress_currency_name,
    guest_adress.currency_symbol AS guest_adress_currency_symbol,
    guest_adress.language_code AS guest_adress_language_code,
    guest_adress.language_name AS guest_adress_language_name,
    guest_adress.christianname AS guest_adress_christianname,
    guest_adress.city AS guest_adress_city,
    guest_adress.email AS guest_adress_email,
    guest_adress.name AS guest_adress_name,
    guest_adress.phone AS guest_adress_phone,
    guest_adress.zipcode AS guest_adress_zipcode,
    guest_adress.street AS guest_adress_street,
    guest_adress.homepage AS guest_adress_homepage,
    guest_adress.remarks AS guest_adress_remarks,
    guest_adress.greeting AS guest_adress_greeting,
    guest_adress.salutation AS guest_adress_salutation,
    guest_adress.title AS guest_adress_title,
    guest_adress.addresstype AS guest_adress_addresstype
   FROM (occ
     LEFT JOIN "AddressFull" guest_adress ON ((occ.guest = guest_adress.id))),
    ((rooms
     LEFT JOIN cat ON ((cat.id = rooms.cat)))
     LEFT JOIN "LocationAddress" ON ((rooms.location = "LocationAddress".id))),
    (res
     LEFT JOIN "AddressFull" reservation_adress ON ((res.addressid = reservation_adress.id)))
  WHERE ((((occ.room = rooms.id) AND (occ.res = res.id)) AND (occ.maintenance IS NULL)) AND (occ.housekeeping IS NULL));


ALTER TABLE public.checkin OWNER TO postgres;

--
-- Name: choice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE choice (
    id bigint NOT NULL,
    groupid integer,
    groupcode character varying(5),
    groupname character varying(50),
    choicecode character varying(5),
    choicetext character varying(100),
    choiceint integer,
    choicefloat numeric(8,2),
    language integer
);


ALTER TABLE public.choice OWNER TO root;

--
-- Name: csc; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE csc (
    id bigint NOT NULL,
    rate bigint,
    fromdate date,
    todate date,
    account bigint,
    amount smallint,
    price numeric(10,2),
    service character varying(100)
);


ALTER TABLE public.csc OWNER TO root;

--
-- Name: job_jobscheduler; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE job_jobscheduler (
    id_job bigint NOT NULL,
    id_jobscheduler bigint NOT NULL,
    id bigint NOT NULL,
    "position" integer
);


ALTER TABLE public.job_jobscheduler OWNER TO root;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE jobs (
    id bigint NOT NULL,
    type character(50),
    name character(100),
    definition text
);


ALTER TABLE public.jobs OWNER TO root;

--
-- Name: jobscheduler; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE jobscheduler (
    id bigint NOT NULL,
    typ character(50),
    name character(100)
);


ALTER TABLE public.jobscheduler OWNER TO root;

--
-- Name: dayclose; Type: VIEW; Schema: public; Owner: JAHAP
--

CREATE VIEW dayclose AS
 SELECT jobs.type,
    jobs.name,
    job_jobscheduler."position",
    job_jobscheduler.id_jobscheduler,
    job_jobscheduler.id_job,
    job_jobscheduler.id,
    jobs.definition
   FROM job_jobscheduler,
    jobs,
    jobscheduler
  WHERE (((job_jobscheduler.id_job = jobs.id) AND (job_jobscheduler.id_jobscheduler = jobscheduler.id)) AND (jobscheduler.typ = 'dayclose'::bpchar))
  ORDER BY job_jobscheduler."position";


ALTER TABLE public.dayclose OWNER TO "JAHAP";

--
-- Name: hotel; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE hotel (
    id integer NOT NULL,
    hotel_code character varying(10),
    hotel_name character varying(100),
    hotel_adress bigint,
    hotel_bankaccountdata1 character varying(200),
    hotel_bankaccountdata2 character varying(200),
    hotel_language integer,
    hotel_country integer,
    hotel_currency integer,
    hotel_footertext character varying(200),
    operationdate date,
    hotel_numberformat character(50),
    hotel_dateformat character(50)
);


ALTER TABLE public.hotel OWNER TO root;

--
-- Name: housekeeping; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE housekeeping (
    id bigint,
    code character varying(255),
    cat_name character varying(100),
    floor character varying(100),
    clean boolean,
    blocks text
);


ALTER TABLE public.housekeeping OWNER TO postgres;

--
-- Name: TABLE housekeeping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE housekeeping IS 'Shows all Rooms with Housekeepingblocks form current date to the futur';


--
-- Name: housekeepingblock; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE housekeepingblock (
    id integer NOT NULL,
    name character varying(100),
    comment character varying(200)
);


ALTER TABLE public.housekeepingblock OWNER TO root;

--
-- Name: log_accounting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE log_accounting (
    id bigint NOT NULL,
    amount numeric(5,0),
    date character varying(50),
    "time" character varying(50),
    account character varying(50),
    account_position bigint,
    positionname character varying(255)
);


ALTER TABLE public.log_accounting OWNER TO root;

--
-- Name: maintenance; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE maintenance (
    id bigint,
    code character varying(255),
    cat_name character varying(100),
    floor character varying(100),
    no_maintenance boolean,
    blocks text
);


ALTER TABLE public.maintenance OWNER TO postgres;

--
-- Name: maintenanceblock; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE maintenanceblock (
    id integer NOT NULL,
    name character varying(100),
    comment character varying(200)
);


ALTER TABLE public.maintenanceblock OWNER TO root;

--
-- Name: payed; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE payed (
    id bigint NOT NULL,
    debit boolean,
    paymenttype bigint,
    openpos boolean,
    total numeric(8,2),
    canceled boolean,
    canceledpayment bigint
);


ALTER TABLE public.payed OWNER TO root;

--
-- Name: paymenttypes; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE paymenttypes (
    id bigint NOT NULL,
    name character varying(50),
    receivable boolean
);


ALTER TABLE public.paymenttypes OWNER TO root;

--
-- Name: rates; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE rates (
    id bigint NOT NULL,
    name character varying(255),
    price numeric(8,2),
    code character varying(50),
    revaccount bigint,
    overnight boolean,
    vattype bigint,
    net boolean
);


ALTER TABLE public.rates OWNER TO root;

--
-- Name: receivables; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE receivables (
    id bigint NOT NULL,
    debit boolean,
    paymenttype bigint
);


ALTER TABLE public.receivables OWNER TO root;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE reports (
    id integer NOT NULL,
    name character varying(50),
    description character varying(200),
    report_group character varying(50),
    report bytea,
    report_layout bytea,
    language integer
);


ALTER TABLE public.reports OWNER TO root;

--
-- Name: reservations; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW reservations AS
 SELECT orderer.christianname AS orderer_christianname,
    orderer.city AS orderer_city,
    orderer.email AS orderer_email,
    orderer.name AS orderer_name,
    orderer.phone AS orderer_phone,
    orderer.street AS orderer_street,
    orderer.zipcode AS orderer_zipcode,
    orderer.greeting AS orderer_greeting,
    orderer.salutation AS orderer_salutation,
    orderer.title AS orderer_title,
    orderer.remarks AS orderer_remarks,
    orderer_language.language_code AS orderer_language_code,
    orderer_language.language_name AS orderer_language_name,
    guest.christianname AS guest_christianname,
    guest.city AS guest_city,
    guest.email AS guest_email,
    guest.name AS guest_name,
    guest.phone AS guest_phone,
    guest.street AS guest_street,
    guest.zipcode AS guest_zipcode,
    guest.greeting AS guest_greeting,
    guest.salutation AS guest_salutation,
    guest.title AS guest_title,
    guest.remarks AS guest_remarks,
    guest_language.language_code AS guest_language_code,
    guest_language.language_name AS guest_language_name,
    services.fromdate AS services_fromdate,
    services.todate AS services_todate,
    services.price AS services_price,
    services.amount AS services_amount,
    rooms.name,
    rooms.code,
    res.resno,
    res.departuredate,
    cat.cat_name,
    cat.cat_description,
    res.arrivaldate,
    hotel.hotel_name,
    hotel.hotel_code,
    hotel.hotel_bankaccountdata1,
    hotel.hotel_bankaccountdata2,
    hotel.hotel_footertext,
    occ.id
   FROM (accounts
     LEFT JOIN csc services ON ((accounts.cscservice = services.id))),
    ((occ
     LEFT JOIN address guest ON ((occ.guest = guest.id)))
     LEFT JOIN language guest_language ON ((guest.language = guest_language.id))),
    ((res
     LEFT JOIN address orderer ON ((res.addressid = orderer.id)))
     LEFT JOIN language orderer_language ON ((orderer.language = orderer_language.id))),
    (rooms
     LEFT JOIN cat ON ((rooms.cat = cat.id))),
    hotel
  WHERE (((occ.room = rooms.id) AND (res.id = occ.res)) AND (occ.account = accounts.id));


ALTER TABLE public.reservations OWNER TO postgres;

--
-- Name: revaccounts; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE revaccounts (
    id bigint NOT NULL,
    revaccountnumber bigint,
    name character varying(255),
    rev_group character varying(50)
);


ALTER TABLE public.revaccounts OWNER TO root;

--
-- Name: revenue; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE revenue (
    id bigint NOT NULL,
    amount numeric(8,2),
    debit boolean,
    accountposition bigint,
    revaccount bigint,
    revdate date
);


ALTER TABLE public.revenue OWNER TO root;

--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.schema_version OWNER TO root;

--
-- Name: seq_store; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE seq_store (
    table_name character varying(255) NOT NULL,
    value bigint
);


ALTER TABLE public.seq_store OWNER TO root;

--
-- Name: sequence; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sequence (
    seq_name character varying(50) NOT NULL,
    seq_count numeric(15,0)
);


ALTER TABLE public.sequence OWNER TO root;

--
-- Name: state; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE state (
    id bigint NOT NULL,
    statetype character(20),
    isfree text,
    name character(30),
    translationstring character varying(100)
);


ALTER TABLE public.state OWNER TO postgres;

--
-- Name: vat; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE vat (
    id bigint NOT NULL,
    debit boolean,
    date date,
    vattype bigint,
    accountposition bigint,
    amount numeric(8,2)
);


ALTER TABLE public.vat OWNER TO root;

--
-- Name: vattype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE vattype (
    id bigint NOT NULL,
    name character varying(100),
    datevat date,
    percentage numeric(5,0)
);


ALTER TABLE public.vattype OWNER TO root;

--
-- Data for Name: account_position; Type: TABLE DATA; Schema: public; Owner: root
--

COPY account_position (id, bill, vat, payment, billed, amount, price, debit, rate, canceledposition, canceled, ratedate, account, positionname) FROM stdin;
\.
COPY account_position (id, bill, vat, payment, billed, amount, price, debit, rate, canceledposition, canceled, ratedate, account, positionname) FROM '$$PATH$$/2240.dat';

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: root
--

COPY accounts (id, balance, checkout, cscservice, address, reservation, checkindate, checkoutdate) FROM stdin;
\.
COPY accounts (id, balance, checkout, cscservice, address, reservation, checkindate, checkoutdate) FROM '$$PATH$$/2239.dat';

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: root
--

COPY address (id, christianname, city, email, name, phone, street, zipcode, country, currency, language, homepage, remarks, greeting, salutation, title, addresstype) FROM stdin;
\.
COPY address (id, christianname, city, email, name, phone, street, zipcode, country, currency, language, homepage, remarks, greeting, salutation, title, addresstype) FROM '$$PATH$$/2241.dat';

--
-- Data for Name: bill; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bill (id, billno, address, billdate, billname, canceled, canceledbill, total, billnostring, uuid, billchange, temp_bill) FROM stdin;
\.
COPY bill (id, billno, address, billdate, billname, canceled, canceledbill, total, billnostring, uuid, billchange, temp_bill) FROM '$$PATH$$/2242.dat';

--
-- Data for Name: bill_no; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bill_no (billno) FROM stdin;
\.
COPY bill_no (billno) FROM '$$PATH$$/2243.dat';

--
-- Data for Name: cat; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cat (id, cat_name, cat_description) FROM stdin;
\.
COPY cat (id, cat_name, cat_description) FROM '$$PATH$$/2266.dat';

--
-- Data for Name: choice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY choice (id, groupid, groupcode, groupname, choicecode, choicetext, choiceint, choicefloat, language) FROM stdin;
\.
COPY choice (id, groupid, groupcode, groupname, choicecode, choicetext, choiceint, choicefloat, language) FROM '$$PATH$$/2244.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: root
--

COPY country (id, country_code, country_name, language, currency) FROM stdin;
\.
COPY country (id, country_code, country_name, language, currency) FROM '$$PATH$$/2245.dat';

--
-- Data for Name: csc; Type: TABLE DATA; Schema: public; Owner: root
--

COPY csc (id, rate, fromdate, todate, account, amount, price, service) FROM stdin;
\.
COPY csc (id, rate, fromdate, todate, account, amount, price, service) FROM '$$PATH$$/2246.dat';

--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: root
--

COPY currency (id, currency_code, currency_name, currency_symbol) FROM stdin;
\.
COPY currency (id, currency_code, currency_name, currency_symbol) FROM '$$PATH$$/2247.dat';

--
-- Data for Name: hotel; Type: TABLE DATA; Schema: public; Owner: root
--

COPY hotel (id, hotel_code, hotel_name, hotel_adress, hotel_bankaccountdata1, hotel_bankaccountdata2, hotel_language, hotel_country, hotel_currency, hotel_footertext, operationdate, hotel_numberformat, hotel_dateformat) FROM stdin;
\.
COPY hotel (id, hotel_code, hotel_name, hotel_adress, hotel_bankaccountdata1, hotel_bankaccountdata2, hotel_language, hotel_country, hotel_currency, hotel_footertext, operationdate, hotel_numberformat, hotel_dateformat) FROM '$$PATH$$/2248.dat';

--
-- Data for Name: housekeepingblock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY housekeepingblock (id, name, comment) FROM stdin;
\.
COPY housekeepingblock (id, name, comment) FROM '$$PATH$$/2267.dat';

--
-- Data for Name: job_jobscheduler; Type: TABLE DATA; Schema: public; Owner: root
--

COPY job_jobscheduler (id_job, id_jobscheduler, id, "position") FROM stdin;
\.
COPY job_jobscheduler (id_job, id_jobscheduler, id, "position") FROM '$$PATH$$/2271.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY jobs (id, type, name, definition) FROM stdin;
\.
COPY jobs (id, type, name, definition) FROM '$$PATH$$/2270.dat';

--
-- Data for Name: jobscheduler; Type: TABLE DATA; Schema: public; Owner: root
--

COPY jobscheduler (id, typ, name) FROM stdin;
\.
COPY jobscheduler (id, typ, name) FROM '$$PATH$$/2269.dat';

--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: root
--

COPY language (id, language_code, language_name) FROM stdin;
\.
COPY language (id, language_code, language_name) FROM '$$PATH$$/2249.dat';

--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: root
--

COPY location (id, building, floor, address_id) FROM stdin;
\.
COPY location (id, building, floor, address_id) FROM '$$PATH$$/2265.dat';

--
-- Data for Name: log_accounting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY log_accounting (id, amount, date, "time", account, account_position, positionname) FROM stdin;
\.
COPY log_accounting (id, amount, date, "time", account, account_position, positionname) FROM '$$PATH$$/2250.dat';

--
-- Data for Name: maintenanceblock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY maintenanceblock (id, name, comment) FROM stdin;
\.
COPY maintenanceblock (id, name, comment) FROM '$$PATH$$/2268.dat';

--
-- Data for Name: occ; Type: TABLE DATA; Schema: public; Owner: root
--

COPY occ (id, arrivaltime, departuretime, arrivaldate, guest, departuredate, room, res, account, maintenance, housekeeping, pax) FROM stdin;
\.
COPY occ (id, arrivaltime, departuretime, arrivaldate, guest, departuredate, room, res, account, maintenance, housekeeping, pax) FROM '$$PATH$$/2251.dat';

--
-- Data for Name: payed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY payed (id, debit, paymenttype, openpos, total, canceled, canceledpayment) FROM stdin;
\.
COPY payed (id, debit, paymenttype, openpos, total, canceled, canceledpayment) FROM '$$PATH$$/2252.dat';

--
-- Data for Name: paymenttypes; Type: TABLE DATA; Schema: public; Owner: root
--

COPY paymenttypes (id, name, receivable) FROM stdin;
\.
COPY paymenttypes (id, name, receivable) FROM '$$PATH$$/2253.dat';

--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY rates (id, name, price, code, revaccount, overnight, vattype, net) FROM stdin;
\.
COPY rates (id, name, price, code, revaccount, overnight, vattype, net) FROM '$$PATH$$/2254.dat';

--
-- Data for Name: receivables; Type: TABLE DATA; Schema: public; Owner: root
--

COPY receivables (id, debit, paymenttype) FROM stdin;
\.
COPY receivables (id, debit, paymenttype) FROM '$$PATH$$/2255.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: root
--

COPY reports (id, name, description, report_group, report, report_layout, language) FROM stdin;
\.
COPY reports (id, name, description, report_group, report, report_layout, language) FROM '$$PATH$$/2264.dat';

--
-- Data for Name: res; Type: TABLE DATA; Schema: public; Owner: root
--

COPY res (id, resno, addressid, arrivaltime, arrivaldate, departuredate, departuretime, state, comment, optiondate) FROM stdin;
\.
COPY res (id, resno, addressid, arrivaltime, arrivaldate, departuredate, departuretime, state, comment, optiondate) FROM '$$PATH$$/2256.dat';

--
-- Data for Name: revaccounts; Type: TABLE DATA; Schema: public; Owner: root
--

COPY revaccounts (id, revaccountnumber, name, rev_group) FROM stdin;
\.
COPY revaccounts (id, revaccountnumber, name, rev_group) FROM '$$PATH$$/2257.dat';

--
-- Data for Name: revenue; Type: TABLE DATA; Schema: public; Owner: root
--

COPY revenue (id, amount, debit, accountposition, revaccount, revdate) FROM stdin;
\.
COPY revenue (id, amount, debit, accountposition, revaccount, revdate) FROM '$$PATH$$/2258.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: root
--

COPY rooms (id, category, code, name, cat, location, clean, no_maintenance, pax) FROM stdin;
\.
COPY rooms (id, category, code, name, cat, location, clean, no_maintenance, pax) FROM '$$PATH$$/2259.dat';

--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: root
--

COPY schema_version (version_rank, installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.
COPY schema_version (version_rank, installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM '$$PATH$$/2238.dat';

--
-- Data for Name: seq_store; Type: TABLE DATA; Schema: public; Owner: root
--

COPY seq_store (table_name, value) FROM stdin;
\.
COPY seq_store (table_name, value) FROM '$$PATH$$/2261.dat';

--
-- Data for Name: sequence; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sequence (seq_name, seq_count) FROM stdin;
\.
COPY sequence (seq_name, seq_count) FROM '$$PATH$$/2260.dat';

--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY state (id, statetype, isfree, name, translationstring) FROM stdin;
\.
COPY state (id, statetype, isfree, name, translationstring) FROM '$$PATH$$/2272.dat';

--
-- Data for Name: vat; Type: TABLE DATA; Schema: public; Owner: root
--

COPY vat (id, debit, date, vattype, accountposition, amount) FROM stdin;
\.
COPY vat (id, debit, date, vattype, accountposition, amount) FROM '$$PATH$$/2262.dat';

--
-- Data for Name: vattype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY vattype (id, name, datevat, percentage) FROM stdin;
\.
COPY vattype (id, name, datevat, percentage) FROM '$$PATH$$/2263.dat';

--
-- Name: JobScheduler_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY jobscheduler
    ADD CONSTRAINT "JobScheduler_pkey" PRIMARY KEY (id);


--
-- Name: PK_REPORTS; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY reports
    ADD CONSTRAINT "PK_REPORTS" PRIMARY KEY (id);


--
-- Name: account_position_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY account_position
    ADD CONSTRAINT account_position_pk PRIMARY KEY (id);


--
-- Name: accounts_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT accounts_pk PRIMARY KEY (id);


--
-- Name: bill_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bill
    ADD CONSTRAINT bill_pk PRIMARY KEY (id);


--
-- Name: cat_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cat
    ADD CONSTRAINT cat_pkey PRIMARY KEY (id);


--
-- Name: csc_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY csc
    ADD CONSTRAINT csc_pk PRIMARY KEY (id);


--
-- Name: housekeepingblock_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY housekeepingblock
    ADD CONSTRAINT housekeepingblock_pkey PRIMARY KEY (id);


--
-- Name: job_jobscheduler_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY job_jobscheduler
    ADD CONSTRAINT job_jobscheduler_pkey PRIMARY KEY (id);


--
-- Name: jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: location_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: log_accounting_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY log_accounting
    ADD CONSTRAINT log_accounting_pk PRIMARY KEY (id);


--
-- Name: maintenanceblock_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY maintenanceblock
    ADD CONSTRAINT maintenanceblock_pkey PRIMARY KEY (id);


--
-- Name: occ_id; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY occ
    ADD CONSTRAINT occ_id PRIMARY KEY (id);


--
-- Name: payed_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY payed
    ADD CONSTRAINT payed_pk PRIMARY KEY (id);


--
-- Name: paymenttypes_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY paymenttypes
    ADD CONSTRAINT paymenttypes_pk PRIMARY KEY (id);


--
-- Name: rates_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY rates
    ADD CONSTRAINT rates_pk PRIMARY KEY (id);


--
-- Name: res_id; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY res
    ADD CONSTRAINT res_id PRIMARY KEY (id);


--
-- Name: revaccount_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY revaccounts
    ADD CONSTRAINT revaccount_pk PRIMARY KEY (id);


--
-- Name: revenue_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY revenue
    ADD CONSTRAINT revenue_pk PRIMARY KEY (id);


--
-- Name: schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: sql130103114019040; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT sql130103114019040 PRIMARY KEY (id);


--
-- Name: sql130111115648290; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY rooms
    ADD CONSTRAINT sql130111115648290 PRIMARY KEY (id);


--
-- Name: sql140207111503680; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY receivables
    ADD CONSTRAINT sql140207111503680 PRIMARY KEY (id);


--
-- Name: sql140207111504890; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sequence
    ADD CONSTRAINT sql140207111504890 PRIMARY KEY (seq_name);


--
-- Name: sql140724165609650; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY seq_store
    ADD CONSTRAINT sql140724165609650 PRIMARY KEY (table_name);


--
-- Name: sql140724165609830; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bill_no
    ADD CONSTRAINT sql140724165609830 PRIMARY KEY (billno);


--
-- Name: sql140908162828940; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY language
    ADD CONSTRAINT sql140908162828940 PRIMARY KEY (id);


--
-- Name: sql140908163644310; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT sql140908163644310 PRIMARY KEY (id);


--
-- Name: sql140909113600460; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY hotel
    ADD CONSTRAINT sql140909113600460 PRIMARY KEY (id);


--
-- Name: sql140916154841950; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY currency
    ADD CONSTRAINT sql140916154841950 PRIMARY KEY (id);


--
-- Name: sql140919175027360; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY choice
    ADD CONSTRAINT sql140919175027360 PRIMARY KEY (id);


--
-- Name: state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY state
    ADD CONSTRAINT state_pkey PRIMARY KEY (id);


--
-- Name: vat_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY vat
    ADD CONSTRAINT vat_pk PRIMARY KEY (id);


--
-- Name: vattype_pk; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY vattype
    ADD CONSTRAINT vattype_pk PRIMARY KEY (id);


--
-- Name: address_idx; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX address_idx ON address USING btree (name);


--
-- Name: fki_job; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX fki_job ON job_jobscheduler USING btree (id_job);


--
-- Name: fki_jobscheduler; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX fki_jobscheduler ON job_jobscheduler USING btree (id_jobscheduler);


--
-- Name: rooms_idx; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX rooms_idx ON rooms USING btree (code);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX schema_version_ir_idx ON schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX schema_version_s_idx ON schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX schema_version_vr_idx ON schema_version USING btree (version_rank);


--
-- Name: sql140205174658020; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658020 ON csc USING btree (rate);


--
-- Name: sql140205174658110; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658110 ON csc USING btree (account);


--
-- Name: sql140205174658200; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658200 ON res USING btree (addressid);


--
-- Name: sql140205174658290; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658290 ON occ USING btree (res);


--
-- Name: sql140205174658380; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658380 ON occ USING btree (guest);


--
-- Name: sql140205174658450; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658450 ON occ USING btree (account);


--
-- Name: sql140205174658530; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658530 ON occ USING btree (room);


--
-- Name: sql140205174658600; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658600 ON revenue USING btree (revaccount);


--
-- Name: sql140205174658710; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205174658710 ON accounts USING btree (address);


--
-- Name: sql140205175226250; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175226250 ON account_position USING btree (rate);


--
-- Name: sql140205175226320; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175226320 ON account_position USING btree (account);


--
-- Name: sql140205175246840; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175246840 ON revenue USING btree (accountposition);


--
-- Name: sql140205175351790; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175351790 ON accounts USING btree (reservation);


--
-- Name: sql140205175411420; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175411420 ON rates USING btree (vattype);


--
-- Name: sql140205175429540; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175429540 ON vat USING btree (vattype);


--
-- Name: sql140205175454250; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175454250 ON account_position USING btree (vat);


--
-- Name: sql140205175512650; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175512650 ON account_position USING btree (payment);


--
-- Name: sql140205175555720; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175555720 ON bill USING btree (address);


--
-- Name: sql140205175612080; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175612080 ON payed USING btree (paymenttype);


--
-- Name: sql140205175634700; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140205175634700 ON rates USING btree (revaccount);


--
-- Name: sql140207111504760; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX sql140207111504760 ON receivables USING btree (paymenttype);


--
-- Name: _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO housekeeping DO INSTEAD  SELECT rooms.id,
    rooms.code,
    cat.cat_name,
    location.floor,
    rooms.clean,
    string_agg(concat(to_char((occ.arrivaldate)::timestamp with time zone, 'DD.MM.YYYY'::text), '-', to_char((occ.departuredate)::timestamp with time zone, 'DD.MM.YYYY'::text)), ' / '::text) AS blocks
   FROM location,
    cat,
    (rooms
     LEFT JOIN occ ON ((((rooms.id = occ.room) AND (occ.arrivaldate >= ('now'::text)::date)) AND (occ.housekeeping IS NOT NULL))))
  WHERE ((rooms.location = location.id) AND (rooms.cat = cat.id))
  GROUP BY rooms.code, rooms.id, location.floor, cat.cat_name;


--
-- Name: _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO maintenance DO INSTEAD  SELECT rooms.id,
    rooms.code,
    cat.cat_name,
    location.floor,
    rooms.no_maintenance,
    string_agg(concat(to_char((occ.arrivaldate)::timestamp with time zone, 'DD.MM.YYYY'::text), '-', to_char((occ.departuredate)::timestamp with time zone, 'DD.MM.YYYY'::text)), ' / '::text) AS blocks
   FROM location,
    cat,
    (rooms
     LEFT JOIN occ ON ((((rooms.id = occ.room) AND (occ.arrivaldate >= ('now'::text)::date)) AND (occ.maintenance IS NOT NULL))))
  WHERE ((rooms.location = location.id) AND (rooms.cat = cat.id))
  GROUP BY rooms.code, rooms.id, location.floor, cat.cat_name;


--
-- Name: _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO "TotalAmountOfCatRooms" DO INSTEAD  SELECT count(*) AS amount,
    cat.cat_name,
    cat.cat_description,
    cat.id
   FROM rooms,
    cat
  WHERE (rooms.cat = cat.id)
  GROUP BY cat.id;


--
-- Name: account_position_revenue_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY revenue
    ADD CONSTRAINT account_position_revenue_fk FOREIGN KEY (accountposition) REFERENCES account_position(id);


--
-- Name: accounts_account_position_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY account_position
    ADD CONSTRAINT accounts_account_position_fk FOREIGN KEY (account) REFERENCES accounts(id);


--
-- Name: accounts_csc_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY csc
    ADD CONSTRAINT accounts_csc_fk FOREIGN KEY (account) REFERENCES accounts(id);


--
-- Name: accounts_occ_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY occ
    ADD CONSTRAINT accounts_occ_fk FOREIGN KEY (account) REFERENCES accounts(id);


--
-- Name: address_accounts_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT address_accounts_fk FOREIGN KEY (address) REFERENCES address(id);


--
-- Name: address_bill_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY bill
    ADD CONSTRAINT address_bill_fk FOREIGN KEY (address) REFERENCES address(id);


--
-- Name: address_occ_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY occ
    ADD CONSTRAINT address_occ_fk FOREIGN KEY (guest) REFERENCES address(id);


--
-- Name: address_res_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY res
    ADD CONSTRAINT address_res_fk FOREIGN KEY (addressid) REFERENCES address(id);


--
-- Name: job; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY job_jobscheduler
    ADD CONSTRAINT job FOREIGN KEY (id_job) REFERENCES jobs(id);


--
-- Name: jobscheduler; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY job_jobscheduler
    ADD CONSTRAINT jobscheduler FOREIGN KEY (id_jobscheduler) REFERENCES jobscheduler(id);


--
-- Name: payed_account_position_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY account_position
    ADD CONSTRAINT payed_account_position_fk FOREIGN KEY (payment) REFERENCES payed(id);


--
-- Name: paymenttypes_payed_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY payed
    ADD CONSTRAINT paymenttypes_payed_fk FOREIGN KEY (paymenttype) REFERENCES paymenttypes(id);


--
-- Name: rates_account_position_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY account_position
    ADD CONSTRAINT rates_account_position_fk FOREIGN KEY (rate) REFERENCES rates(id);


--
-- Name: rates_csc_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY csc
    ADD CONSTRAINT rates_csc_fk FOREIGN KEY (rate) REFERENCES rates(id);


--
-- Name: rcvablespymenttype; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY receivables
    ADD CONSTRAINT rcvablespymenttype FOREIGN KEY (paymenttype) REFERENCES paymenttypes(id);


--
-- Name: res_accounts_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT res_accounts_fk FOREIGN KEY (reservation) REFERENCES res(id);


--
-- Name: res_occ_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY occ
    ADD CONSTRAINT res_occ_fk FOREIGN KEY (res) REFERENCES res(id);


--
-- Name: revaccounts_rates_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY rates
    ADD CONSTRAINT revaccounts_rates_fk FOREIGN KEY (revaccount) REFERENCES revaccounts(id);


--
-- Name: revenue_revenueacc_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY revenue
    ADD CONSTRAINT revenue_revenueacc_fk FOREIGN KEY (revaccount) REFERENCES revaccounts(id);


--
-- Name: rooms_occ_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY occ
    ADD CONSTRAINT rooms_occ_fk FOREIGN KEY (room) REFERENCES rooms(id);


--
-- Name: vat_account_position_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY account_position
    ADD CONSTRAINT vat_account_position_fk FOREIGN KEY (vat) REFERENCES vat(id);


--
-- Name: vattype_rates_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY rates
    ADD CONSTRAINT vattype_rates_fk FOREIGN KEY (vattype) REFERENCES vattype(id);


--
-- Name: vattype_vat_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY vat
    ADD CONSTRAINT vattype_vat_fk FOREIGN KEY (vattype) REFERENCES vattype(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

